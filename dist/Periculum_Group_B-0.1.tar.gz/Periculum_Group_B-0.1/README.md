# Periculum_Group_B
 Risk Based Segmentation Package
