# Periculum_Group_B_IE
 Risk Based Segmentation Package
